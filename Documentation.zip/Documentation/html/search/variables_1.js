var searchData=
[
  ['count_42',['count',['../class_lettertype.html#a476d614c0cafcc189333f95046372e96',1,'Lettertype']]]
];
