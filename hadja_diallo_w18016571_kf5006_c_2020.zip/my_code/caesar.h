#include <vector> ///library used for dynamic table
#include <fstream> ///library used to read and write to files

using namespace std;

class Lettertype {

public:
	char letter;
	int count;
};
///Lettertpe is a class contaning the letter and the count
///Caesar class has methods that are public because it will use the user's input to decrypt the string
///as default all of the rest of functions ae private
class Caesar {
public:
	Caesar();	///caesar() is the default constructor, sets shift data to 0

	void print_character_frequency(Lettertype *arrayout, int my_size); ///protytype to print the frequency of each character
	void decrypt(int key, string inputfile, string outputfile); ///prototype for decrypt function , decypt uses the key found in max index to decrypt string

	Lettertype* character_count(vector<char> array, int size); ///prototype to find occcurence of a letter in table called character_frequency

};

int find_character_in_table(Lettertype *array, int size, char letter_to_search);
int max_index(Lettertype *array, int size); ///function prototype 
bool is_upper(char input_char);
char to_upper(char input_char);
int key_calculator(char language_frequent_character,
		char most_frequent_character); ///prtototype to find key for character
bool is_alpha(char input_char); ///function prototype checks if a letter is alpha
void read_decrypted_file(string outputFile); ///read decrypt file prototype

bool is_alphabet(char input_char); ///function prototype for is_alphabet
void print_vector(vector<char> arrayout); ///prototype of print_vector function, whch will print the vector passed as an argument in the function

///vector, type of table i.e. char and name of table for dynamic tbales
vector<char> read_file(string inputFile); ///prototype to read a file function return dynamic table 


