#include <iostream>

#include <string>

#include <cctype>

#include <locale>

#include <fstream> ///library used to read and write to files

#include <vector> ///for the dynamic table library, 

#include <math.h> ///library for abs, preven negative number

#include <stdlib.h>

#include "caesar.h" ///header file

using namespace std;

int main(int argc, char *argv[]) ///argc is the number of arguments , argv is the vector i.e the string of the array

		{

///varibale declaractions

	char char_choice;

	int choice;

	int test_choice = 1;

	int again = 0;

	char use_suggest_key;

	int suggest_key;

	int user_key;

	char user_key_char;

	int key; ///declaration of variable key to store the key returned by max_index or user's own key

	int try_other_key = 0;

	if (argc != 3) {

		cout
				<< "Usage: programme name <encryptedfile.txt>  <decryptedfile.txt> "
				<< endl;

		exit(1);

	}

	cout << "   /===========================================================\\"
			<< endl;

	cout << "  |      Welcome to the world of Cesar cipher                   |"
			<< endl;

	cout << "  |      Author : Hadja                                         |"
			<< endl;

	cout << "  |      Version : 1.0                                          |"
			<< endl;

	cout << "   \\===========================================================/"
			<< endl << endl;

	string inputFile = argv[1];

	string outputFile = argv[2];

	vector<char> arrayout; ///declaration of tables 

	Lettertype *character_frequency;

	int size;

	int maxindex; ///storing value of max index returned by max_index function

	ifstream readmyFile(inputFile);

	Caesar caesar_main; ///calling of default constructor

	if (!readmyFile) {

		cout << "An error occured reading the input file" << endl;

		exit(1); ///closes the program if can't open the file to read it

	}

	ofstream writemyFile(outputFile);

	if (!writemyFile) {

		cout << "An error occured opening the output file" << endl;

		exit(1); ///closes the program if can't open to write to the file 

	}

	arrayout = read_file(inputFile); ///the table arrayout will contain the results of the characters frequencies found in the function read file, characters without any numbers, spaces, symbols

	size = arrayout.size();

	print_vector(arrayout); /// prints the vector of characters returned by the read file function

	do {

		///main menu of program - for a friendly and usable program

		cout
				<< "   *********   What do you want to do   ?        ***************"
				<< endl << endl;

		cout << "   ==> 1. Analyse frequent characters               " << endl;

		cout << "   ==> 2. Decrypt  file                             " << endl;

		cout << "   ==> 3. Encrypt  file                             " << endl;

		cout << "   ==> 4. Exit de program                           " << endl;

		cin >> char_choice;
		cout << endl;

		while (!isdigit(char_choice)) { ///this loop will continue until the user enters a digit

			cout
					<< "Wrong input : must be numeric and chosen from the proposed list Please, try again: ";

			cin >> char_choice;

		}

		choice = (int) char_choice - 48; ///convert a char into a int 

		if (choice == 1) {

			cout << " You chose Analyse frequent characters :  " << choice
					<< endl;

			again = 1;

			character_frequency = caesar_main.character_count(arrayout, size); ///outputs the frequency of the characters in a table

			/// caesar_main.character_count , caesar_main is used to access public member of the class called Caesar, 

			/// caesar_main contains the methods (functions) of a class, character_count  

		} else if (choice == 2) {

			int test = 1;

			character_frequency = caesar_main.character_count(arrayout, size); ///outputs the frequency of the characters in a table
			cout << endl;

			suggest_key = max_index(character_frequency, size);
			cout << endl;

			///do while allows the user to choose a different key, until they decide to exit the program
			do {

				cout
						<< " Do you want to use the suggested key to decrypt ? ==> 1 : "
						<< endl;

				cout << " Use your own key?  ==> 2 : " << endl;
				cout << " Exit the the decryption program  ==> 3 : " << endl;

				cin >> use_suggest_key;
				cout << endl;

				if (use_suggest_key == '1') {

					key = suggest_key;
					character_frequency = caesar_main.character_count(arrayout,
							size);

					key = suggest_key;
					caesar_main.decrypt(key, inputFile, outputFile);
					read_decrypted_file(outputFile);

				} else if (use_suggest_key == '2') {

					cout << "plese enter your suggested key : " << endl;

					cin >> user_key_char;

					if (isdigit(user_key_char)) {

						user_key = (int) user_key_char - 48; ///convert a char into int , using the user's input

						key = user_key;
						caesar_main.decrypt(key, inputFile, outputFile);
						read_decrypted_file(outputFile);

					} else {

						cout << "An error occured, the key must be a numeric "
								<< endl;

						again = 1; ///again = 1, gives the use choice to return back to the program and try again

					}

				} else {
					test = 0;
				}

			} while (test == 1);

			again = 1; ///exit 1 will return to main menu

		} else if (choice == 3) {

			cout << "Encrypt option is not available at the moment" << endl;

			again = 1; /// again = 1 will return to program  menu

		} else if (choice == 4) {

			cout << "See you again next time, Bye" << endl;

			again = 0; ///again = 0 means the user can exit the program

		}

		else {

			cout << " Error : your choice is not valid .. :  " << endl;

			again = 1;

		}

	} while (again == 1);

	return 0;

}


